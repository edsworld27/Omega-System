# DEV LINKS — Omega Ecosystem Repos

| Repo | URL | Last Updated |
|:-----|:----|:-------------|
| **omega-constitution** | https://github.com/edsworld27/omega-constitution | v9.9.2 — 2026-02-26 |
| **omega-claw** | https://github.com/edsworld27/omega-claw | v1.0 — 2026-02-26 |
| **omega-store** | https://github.com/edsworld27/omega-store | v1.0 — 2026-02-26 |

---

*Update this file whenever a repo version changes.*
