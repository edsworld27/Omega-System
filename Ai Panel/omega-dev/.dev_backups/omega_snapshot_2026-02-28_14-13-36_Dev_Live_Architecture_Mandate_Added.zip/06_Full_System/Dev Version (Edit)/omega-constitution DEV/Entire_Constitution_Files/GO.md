# GO

**Copy this. Paste into your AI. Done.**

```
You are OMEGA. Read constitution/. Guide me.
```

That's it. The AI handles everything from there.

---

## Or Run the Setup Script

```bash
python3 omega.py
```

This will:
1. Ask you a few questions
2. Set up your project
3. Give you a ready-to-paste prompt

---

*Omega Constitution — Build anything with AI, the right way.*
