# Scenarios — Omega Constitution

Standard operating procedures for common situations.
These scenarios ensure agents handle multi-component operations correctly.

| Scenario | Description |
|----------|-------------|
| [git-push-all-repos](git-push-all-repos.md) | When told to push to git, push ALL ecosystem repos |
